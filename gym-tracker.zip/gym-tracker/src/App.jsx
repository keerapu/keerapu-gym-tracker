import { useEffect, useState, useCallback } from 'react'
import { kvGet, kvSet } from './supabaseClient'

const todayStr = () => new Date().toISOString().slice(0, 10)

function compressImage(file, maxW = 320, quality = 0.55) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      const img = new Image()
      img.onload = () => {
        const scale = Math.min(1, maxW / img.width)
        const canvas = document.createElement('canvas')
        canvas.width = img.width * scale
        canvas.height = img.height * scale
        const ctx = canvas.getContext('2d')
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
        resolve(canvas.toDataURL('image/jpeg', quality))
      }
      img.onerror = reject
      img.src = e.target.result
    }
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}

const TABS = [
  { id: 'workout', label: 'Workout', icon: '🏋️' },
  { id: 'weight', label: 'Berat', icon: '⚖️' },
  { id: 'template', label: 'Template', icon: '📋' },
  { id: 'notes', label: "Do/Dont", icon: '✅' },
  { id: 'reminders', label: 'Reminder', icon: '⏰' },
]

export default function App() {
  const [tab, setTab] = useState('workout')
  const [loading, setLoading] = useState(true)
  const [workouts, setWorkouts] = useState([])
  const [weights, setWeights] = useState([])
  const [templates, setTemplates] = useState([])
  const [water, setWater] = useState({})
  const [notes, setNotes] = useState([])
  const [reminders, setReminders] = useState([])

  useEffect(() => {
    (async () => {
      const [w, wt, tpl, wtr, nt, rm] = await Promise.all([
        kvGet('workouts', []),
        kvGet('weights', []),
        kvGet('templates', []),
        kvGet('water', {}),
        kvGet('notes', []),
        kvGet('reminders', []),
      ])
      setWorkouts(w); setWeights(wt); setTemplates(tpl)
      setWater(wtr); setNotes(nt); setReminders(rm)
      setLoading(false)
    })()
  }, [])

  const persist = useCallback((key, value, setter) => {
    setter(value)
    kvSet(key, value).catch((e) => console.error('save failed', key, e))
  }, [])

  const todayWater = water[todayStr()] || 0
  const waterGoal = 2000
  const waterPct = Math.min(100, Math.round((todayWater / waterGoal) * 100))

  if (loading) {
    return <div className="app"><div className="main"><p className="empty">Memuat data...</p></div></div>
  }

  return (
    <div className="app">
      <header className="header">
        <div className="eyebrow">Gym Tracker</div>
        <h1>Halo, sikat hari ini 💪</h1>
      </header>

      <div className="water-strip">
        <span style={{ fontSize: 20 }}>💧</span>
        <div className="water-fill-track">
          <div className="water-fill" style={{ width: `${waterPct}%` }} />
        </div>
        <span className="water-label">{todayWater}/{waterGoal}ml</span>
        <button
          className="btn-icon"
          onClick={() => {
            const next = { ...water, [todayStr()]: todayWater + 250 }
            persist('water', next, setWater)
          }}
        >+</button>
      </div>

      <main className="main">
        {tab === 'workout' && (
          <WorkoutTab
            workouts={workouts}
            templates={templates}
            onChange={(v) => persist('workouts', v, setWorkouts)}
          />
        )}
        {tab === 'weight' && (
          <WeightTab weights={weights} onChange={(v) => persist('weights', v, setWeights)} />
        )}
        {tab === 'template' && (
          <TemplateTab templates={templates} onChange={(v) => persist('templates', v, setTemplates)} />
        )}
        {tab === 'notes' && (
          <NotesTab notes={notes} onChange={(v) => persist('notes', v, setNotes)} />
        )}
        {tab === 'reminders' && (
          <RemindersTab reminders={reminders} onChange={(v) => persist('reminders', v, setReminders)} />
        )}
      </main>

      <nav className="tabbar">
        {TABS.map((t) => (
          <button
            key={t.id}
            className={`tab ${tab === t.id ? 'active' : ''}`}
            onClick={() => setTab(t.id)}
          >
            <span className="icon">{t.icon}</span>
            {t.label}
          </button>
        ))}
      </nav>
    </div>
  )
}

function WorkoutTab({ workouts, templates, onChange }) {
  const [form, setForm] = useState({ exercise: '', sets: '', reps: '', weight: '' })

  const add = () => {
    if (!form.exercise) return
    const entry = { id: Date.now(), date: todayStr(), ...form }
    onChange([entry, ...workouts])
    setForm({ exercise: '', sets: '', reps: '', weight: '' })
  }

  const remove = (id) => onChange(workouts.filter((w) => w.id !== id))

  const todays = workouts.filter((w) => w.date === todayStr())
  const history = workouts.filter((w) => w.date !== todayStr())

  return (
    <>
      <h2 className="section-title">Catat Set</h2>
      <div className="card">
        {templates.length > 0 && (
          <div className="form-row">
            <select
              onChange={(e) => {
                const t = templates.find((x) => String(x.id) === e.target.value)
                if (t) setForm((f) => ({ ...f, exercise: t.exercises[0] || '' }))
              }}
              defaultValue=""
            >
              <option value="" disabled>Pilih dari template...</option>
              {templates.map((t) => (
                <option key={t.id} value={t.id}>{t.name}</option>
              ))}
            </select>
          </div>
        )}
        <div className="form-row">
          <input
            placeholder="Nama exercise (misal Bench Press)"
            value={form.exercise}
            onChange={(e) => setForm({ ...form, exercise: e.target.value })}
          />
        </div>
        <div className="form-row">
          <input placeholder="Set" inputMode="numeric" value={form.sets} onChange={(e) => setForm({ ...form, sets: e.target.value })} />
          <input placeholder="Reps" inputMode="numeric" value={form.reps} onChange={(e) => setForm({ ...form, reps: e.target.value })} />
          <input placeholder="Beban (kg)" inputMode="decimal" value={form.weight} onChange={(e) => setForm({ ...form, weight: e.target.value })} />
        </div>
        <button className="btn" onClick={add}>Simpan set</button>
      </div>

      <h2 className="section-title">Hari ini</h2>
      <div className="card">
        {todays.length === 0 && <p className="empty">Belum ada set hari ini.</p>}
        {todays.map((w) => (
          <div className="list-item" key={w.id}>
            <div>
              <strong>{w.exercise}</strong>
              <div className="meta">{w.sets || '-'}x{w.reps || '-'} @ {w.weight || '-'}kg</div>
            </div>
            <button className="btn-icon" onClick={() => remove(w.id)}>✕</button>
          </div>
        ))}
      </div>

      {history.length > 0 && (
        <>
          <h2 className="section-title">Riwayat</h2>
          <div className="card">
            {history.slice(0, 30).map((w) => (
              <div className="list-item" key={w.id}>
                <div>
                  <strong>{w.exercise}</strong>
                  <div className="meta">{w.date} · {w.sets || '-'}x{w.reps || '-'} @ {w.weight || '-'}kg</div>
                </div>
                <button className="btn-icon" onClick={() => remove(w.id)}>✕</button>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  )
}

function WeightTab({ weights, onChange }) {
  const [val, setVal] = useState('')
  const [photo, setPhoto] = useState(null)
  const [busy, setBusy] = useState(false)

  const add = () => {
    if (!val) return
    const entry = { id: Date.now(), date: todayStr(), weight: val, photo }
    onChange([entry, ...weights])
    setVal(''); setPhoto(null)
  }

  const remove = (id) => onChange(weights.filter((w) => w.id !== id))

  const handlePhoto = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    setBusy(true)
    try {
      const dataUrl = await compressImage(file)
      setPhoto(dataUrl)
    } finally {
      setBusy(false)
    }
  }

  const last = weights[0]

  return (
    <>
      <h2 className="section-title">Catat Berat Badan</h2>
      <div className="card">
        <div className="form-row">
          <input placeholder="Berat (kg)" inputMode="decimal" value={val} onChange={(e) => setVal(e.target.value)} />
        </div>
        <div className="form-row" style={{ alignItems: 'center' }}>
          <label className="photo-input-label" style={{ flex: 1 }}>
            {busy ? 'Memproses foto...' : photo ? 'Foto siap ✓' : '+ Foto progress (opsional)'}
            <input type="file" accept="image/*" capture="environment" onChange={handlePhoto} style={{ display: 'none' }} />
          </label>
          {photo && <img src={photo} className="thumb" alt="preview" />}
        </div>
        <button className="btn" onClick={add}>Simpan berat</button>
      </div>

      {last && (
        <p className="empty" style={{ padding: '0 4px 10px' }}>Terakhir: {last.weight}kg pada {last.date}</p>
      )}

      <h2 className="section-title">Riwayat Berat</h2>
      <div className="card">
        {weights.length === 0 && <p className="empty">Belum ada catatan berat.</p>}
        {weights.map((w) => (
          <div className="list-item" key={w.id}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              {w.photo && <img src={w.photo} className="thumb" alt="" />}
              <div>
                <strong>{w.weight} kg</strong>
                <div className="meta">{w.date}</div>
              </div>
            </div>
            <button className="btn-icon" onClick={() => remove(w.id)}>✕</button>
          </div>
        ))}
      </div>
    </>
  )
}

function TemplateTab({ templates, onChange }) {
  const [name, setName] = useState('')
  const [exercises, setExercises] = useState('')

  const add = () => {
    if (!name) return
    const entry = {
      id: Date.now(),
      name,
      exercises: exercises.split(',').map((x) => x.trim()).filter(Boolean),
    }
    onChange([entry, ...templates])
    setName(''); setExercises('')
  }

  const remove = (id) => onChange(templates.filter((t) => t.id !== id))

  return (
    <>
      <h2 className="section-title">Bikin Template</h2>
      <div className="card">
        <div className="form-row">
          <input placeholder="Nama template (misal Push Day)" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div className="form-row">
          <input placeholder="Exercise, pisah pakai koma" value={exercises} onChange={(e) => setExercises(e.target.value)} />
        </div>
        <button className="btn" onClick={add}>Simpan template</button>
      </div>

      <h2 className="section-title">Template Kamu</h2>
      <div className="card">
        {templates.length === 0 && <p className="empty">Belum ada template. Contoh: Push / Pull / Legs.</p>}
        {templates.map((t) => (
          <div className="list-item" key={t.id}>
            <div>
              <strong>{t.name}</strong>
              <div className="meta">{t.exercises.join(', ')}</div>
            </div>
            <button className="btn-icon" onClick={() => remove(t.id)}>✕</button>
          </div>
        ))}
      </div>
    </>
  )
}

function NotesTab({ notes, onChange }) {
  const [text, setText] = useState('')
  const [type, setType] = useState('do')

  const add = () => {
    if (!text) return
    onChange([{ id: Date.now(), text, type }, ...notes])
    setText('')
  }

  const remove = (id) => onChange(notes.filter((n) => n.id !== id))

  return (
    <>
      <h2 className="section-title">Do's & Don'ts</h2>
      <div className="card">
        <div className="form-row">
          <select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="do">Do</option>
            <option value="dont">Don't</option>
          </select>
        </div>
        <div className="form-row">
          <input placeholder="Misal: pemanasan 5 menit dulu" value={text} onChange={(e) => setText(e.target.value)} />
        </div>
        <button className="btn" onClick={add}>Simpan catatan</button>
      </div>

      <div className="card">
        {notes.length === 0 && <p className="empty">Belum ada catatan.</p>}
        {notes.map((n) => (
          <div className="list-item" key={n.id}>
            <div>
              <span className={`chip ${n.type}`}>{n.type === 'do' ? 'DO' : "DON'T"}</span>
              {n.text}
            </div>
            <button className="btn-icon" onClick={() => remove(n.id)}>✕</button>
          </div>
        ))}
      </div>
    </>
  )
}

function RemindersTab({ reminders, onChange }) {
  const [text, setText] = useState('')
  const [time, setTime] = useState('18:00')

  useEffect(() => {
    if (reminders.length > 0 && 'Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission()
    }
  }, [reminders.length])

  useEffect(() => {
    const iv = setInterval(() => {
      const now = new Date()
      const hhmm = now.toTimeString().slice(0, 5)
      reminders.forEach((r) => {
        if (r.time === hhmm && 'Notification' in window && Notification.permission === 'granted') {
          new Notification('Gym Tracker', { body: r.text })
        }
      })
    }, 60000)
    return () => clearInterval(iv)
  }, [reminders])

  const add = () => {
    if (!text) return
    onChange([{ id: Date.now(), text, time }, ...reminders])
    setText('')
  }

  const remove = (id) => onChange(reminders.filter((r) => r.id !== id))

  return (
    <>
      <h2 className="section-title">Reminder</h2>
      <div className="card">
        <div className="form-row">
          <input placeholder="Misal: minum air, jangan lupa gym" value={text} onChange={(e) => setText(e.target.value)} />
          <input type="time" value={time} onChange={(e) => setTime(e.target.value)} style={{ flex: '0 0 110px' }} />
        </div>
        <button className="btn" onClick={add}>Simpan reminder</button>
        <p className="meta" style={{ marginTop: 8 }}>
          Catatan: notifikasi cuma nyala kalau tab ini lagi kebuka di browser/HP kamu.
        </p>
      </div>

      <div className="card">
        {reminders.length === 0 && <p className="empty">Belum ada reminder.</p>}
        {reminders.map((r) => (
          <div className="list-item" key={r.id}>
            <div>
              <strong>{r.time}</strong>
              <div className="meta">{r.text}</div>
            </div>
            <button className="btn-icon" onClick={() => remove(r.id)}>✕</button>
          </div>
        ))}
      </div>
    </>
  )
}
