import { createClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

export const supabase = createClient(url, anonKey)

// Helper: gym_data table works as a simple key-value store.
// key = string (e.g. "workouts"), value = JSON-stringified data.
export async function kvGet(key, fallback) {
  const { data, error } = await supabase
    .from('gym_data')
    .select('value')
    .eq('key', key)
    .maybeSingle()
  if (error || !data) return fallback
  try {
    return JSON.parse(data.value)
  } catch {
    return fallback
  }
}

export async function kvSet(key, value) {
  const payload = {
    key,
    value: JSON.stringify(value),
    updated_at: new Date().toISOString(),
  }
  const { error } = await supabase
    .from('gym_data')
    .upsert(payload, { onConflict: 'key' })
  if (error) throw error
}
